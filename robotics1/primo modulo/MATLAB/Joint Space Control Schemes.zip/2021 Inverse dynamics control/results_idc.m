close all


figure(1), p560.plot(q(1:5:size(q,1),:)) %traiettoria animata

%errore di tracking
figure(2), plot(T,qref(:,2:end)-q), legend('Giunto 1','Giunto 2','Giunto 3','Giunto 4','Giunto 5','Giunto 6'), grid on, title('Errori di posizionamento dei giunti'), ylabel('Errore (rad)'), xlabel('Tempo (s)')

%errore qdd-y
figure(3), plot(T,qdd-y), grid on, legend('Giunto 1','Giunto 2','Giunto 3','Giunto 4','Giunto 5','Giunto 6'), title('qdd-y'), xlabel('Tempo(s)'), ylabel('Errore (rad/s^2)')

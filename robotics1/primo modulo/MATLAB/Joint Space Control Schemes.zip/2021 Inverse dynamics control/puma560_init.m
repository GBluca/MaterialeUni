% NB Il modello funziona con la versioone ante 2017 del toolbox!!! 

clear all, clc

mdl_puma560 %generazione modello Puma560

%configurazioni dei giunti iniziale e finale
qn(3)=-qn(3); %modifica per rientrare nei limiti di mobilit� dei giunti
qi=qz; 
qf=qn;

%generazione traiettoria nello spazio dei giunti
T = (0:0.01:10)'; %vettore dei tempi
[qref,qdref,qddref]=jtraj(qi,qf,T); %traiettoria V ordine
qref=[T qref]; %posizione
qdref=[T qdref]; %velocit�
qddref=[T qddref]; %accelerazione

%impostazione matrici di guadagno per contenere errori entro 1e-6 rad
wn = [1,150,0.7,1,150,1]; %pulsazioni naturali 
delta = sqrt(0.5); %fattore di smorzamento
Kd=diag(2*delta*wn);
Kp=diag(wn.^2);


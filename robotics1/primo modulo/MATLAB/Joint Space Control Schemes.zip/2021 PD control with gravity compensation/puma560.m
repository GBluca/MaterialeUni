clear all

clc

mdl_puma560
qd = qz ; 

w=[0 0 -40 0 0 0]'; % peso massimo sull'end effector (come da specifica)
Cr = p560.pay(qs,w,'0'); %calcolo forze generalizzate dovute al peso
p=6910;d=43;
Kp=p*eye(6);
Kd=d*eye(6);
